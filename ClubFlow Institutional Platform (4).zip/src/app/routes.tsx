import { createBrowserRouter, Navigate, Outlet } from "react-router";
import { Layout } from "./layout";
import { Login } from "./pages/Login";
import { Signup } from "./pages/Signup";
import { Landing } from "./pages/Landing";
import { ClubHeadOverview } from "./pages/ClubHead/ClubHeadOverview";
import { ProposalForm } from "./pages/ClubHead/ProposalForm";
import { ProposalsList } from "./pages/ClubHead/ProposalsList";
import { CouncilDashboard } from "./pages/Council/CouncilDashboard";
import { CouncilApprovals } from "./pages/Council/CouncilApprovals";
import { StudentDashboard } from "./pages/Student/StudentDashboard";
import { VideoCall } from "./pages/VideoCall";
import { AnalyticsDashboard } from "./components/AnalyticsDashboard";
import { ReimbursementForm } from "./pages/ClubHead/ReimbursementForm";
import { ChatInterface } from "./pages/ChatInterface";
import { EventsManagement } from "./pages/ClubHead/EventsManagement";
import { RoomBooking } from "./pages/ClubHead/RoomBooking";
import { FundsAndBills } from "./pages/ClubHead/FundsAndBills";
import { StudentEvents } from "./pages/Student/StudentEvents";
import { StudentMemberships } from "./pages/Student/StudentMemberships";
import { ClubDetails } from "./pages/Student/ClubDetails";
import { ClubsList } from "./pages/Council/ClubsList";
import { BudgetOverview } from "./pages/Council/BudgetOverview";

// Club Portal Pages
import { ClubDashboard } from "./pages/Club/ClubDashboard";
import { UpdateDetails } from "./pages/Club/UpdateDetails";
import { BookRooms } from "./pages/Club/BookRooms";
import { SubmitBills } from "./pages/Club/SubmitBills";
import { PitchEvents } from "./pages/Club/PitchEvents";
import { RequestFunds } from "./pages/Club/RequestFunds";

// Admin Portal Pages
import { AdminDashboard } from "./pages/Admin/AdminDashboard";
import { ReviewSubmissions } from "./pages/Admin/ReviewSubmissions";
import { ClubAnalytics } from "./pages/Admin/ClubAnalytics";
import { ChatWithClubs } from "./pages/Admin/ChatWithClubs";

function AppLayout() {
  return (
    <Layout>
      <Outlet />
    </Layout>
  );
}

export const router = createBrowserRouter([
  {
    path: "/",
    element: <Login />,
  },
  {
    path: "/login",
    element: <Login />,
  },
  {
    path: "/signup",
    element: <Signup />,
  },
  {
    path: "/select-role",
    element: <Landing />,
  },
  {
    path: "/",
    element: <AppLayout />,
    children: [
      // Club Portal Routes
      { path: "club", element: <ClubDashboard /> },
      { path: "club/update-details", element: <UpdateDetails /> },
      { path: "club/book-rooms", element: <BookRooms /> },
      { path: "club/submit-bills", element: <SubmitBills /> },
      { path: "club/pitch-events", element: <PitchEvents /> },
      { path: "club/request-funds", element: <RequestFunds /> },
      
      // Club Head Routes (keeping existing for backward compatibility)
      { path: "club-head", element: <ClubHeadOverview /> },
      { path: "club-head/proposals", element: <ProposalsList /> },
      { path: "club-head/proposals/new", element: <ProposalForm /> },
      { path: "club-head/funds", element: <FundsAndBills /> },
      { path: "club-head/rooms", element: <RoomBooking /> },
      { path: "club-head/chat", element: <ChatInterface /> },
      { path: "club-head/meetings", element: <VideoCall /> },
      { path: "club-head/events", element: <EventsManagement /> },

      // Admin Routes
      { path: "admin", element: <AdminDashboard /> },
      { path: "admin/review", element: <ReviewSubmissions /> },
      { path: "admin/analytics", element: <ClubAnalytics /> },
      { path: "admin/chat-clubs", element: <ChatWithClubs /> },
      { path: "admin/review-funds", element: <ReviewSubmissions /> },
      { path: "admin/review-events", element: <ReviewSubmissions /> },
      { path: "admin/review-rooms", element: <ReviewSubmissions /> },
      { path: "admin/review-bills", element: <ReviewSubmissions /> },

      // Council Routes
      { path: "council", element: <CouncilDashboard /> },
      { path: "council/approvals", element: <CouncilApprovals /> },
      { path: "council/analytics", element: <AnalyticsDashboard /> },
      { path: "council/pitches", element: <VideoCall /> },
      { path: "council/budget", element: <BudgetOverview /> },
      { path: "council/clubs", element: <ClubsList /> },

      // Student Routes
      { path: "student", element: <StudentDashboard /> },
      { path: "student/events", element: <StudentEvents /> },
      { path: "student/memberships", element: <StudentMemberships /> },
      { path: "student/clubs/:id", element: <ClubDetails /> },
      
      // Catch all
      { path: "*", element: <div className="p-12 text-center text-gray-500">Page not found</div> },
    ],
  },
]);